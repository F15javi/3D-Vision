#include "cube.h"
#include "GLConvenience.h"
#include "QtConvenience.h"
using namespace std;


cube::cube(const std::vector<QVector4D>  origin)
{
    type = SceneObjectType::ST_CUBE;
    Cube.push_back(origin[0]);
    Cube.push_back(origin[1]);
    Cube.push_back(origin[2]);
    Cube.push_back(origin[3]);
    Cube.push_back(origin[4]);
    Cube.push_back(origin[5]);
    Cube.push_back(origin[6]);
    Cube.push_back(origin[7]);
}

void cube::affineMap(const QMatrix4x4& M)
{
}


void cube::draw(const RenderCamera& renderer, const QColor& color, float lineWidth) const
{
    QColor c = color;
    c.toHsv();

    renderer.renderLine(Cube[0],Cube[1],c,lineWidth);
    renderer.renderLine(Cube[0],Cube[2],c,lineWidth);
    renderer.renderLine(Cube[0],Cube[4],c,lineWidth);

    renderer.renderLine(Cube[1],Cube[3],c,lineWidth);
    renderer.renderLine(Cube[1],Cube[5],c,lineWidth);

    renderer.renderLine(Cube[2],Cube[3],c,lineWidth);
    renderer.renderLine(Cube[2],Cube[6],c,lineWidth);

    renderer.renderLine(Cube[3],Cube[7],c,lineWidth);

    renderer.renderLine(Cube[4],Cube[5],c,lineWidth);
    renderer.renderLine(Cube[4],Cube[6],c,lineWidth);

    renderer.renderLine(Cube[5],Cube[7],c,lineWidth);

    renderer.renderLine(Cube[6],Cube[7],c,lineWidth);
}
