#pragma once

#include "QtConvenience.h"
#include "SceneObject.h"

#include <QMatrix4x4>

class cube: public SceneObject
{
private:
    std::vector<QVector4D> Cube;

public:
    cube(const std::vector<QVector4D>  origin);
    virtual ~cube() override {}

    virtual void affineMap(const QMatrix4x4  & matrix) override;
    virtual void draw     (const RenderCamera& renderer,
                           const QColor      & color     = COLOR_AXES,
                           float               lineWidth = 3.0f      ) const override;
};
