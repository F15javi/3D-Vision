
#ifndef CAMERA_H
#define CAMERA_H

#pragma once


#include "QtConvenience.h"
#include "SceneObject.h"

#include <QMatrix4x4>
#include "Axes.h"





class Camera: public SceneObject
{
private:
    std::vector<QVector3D> axes;
    QMatrix4x4             rotation;
    QVector4D              origin;
    QVector4D  normal;

public:
    Camera(const QVector4D&  origin   = E0,
         const QMatrix4x4& rotation = QMatrix4x4());
    virtual ~Camera() override {}

    virtual void affineMap(const QMatrix4x4  & matrix) override;
    virtual void draw     (const RenderCamera& renderer,
                      const QColor      & color     = COLOR_AXES,
                      float               lineWidth = 3.0f      ) const override;


    virtual void affineMap2(const QMatrix4x4  & matrix) override;
    virtual void draw2     (const RenderCamera& renderer,
                      const QColor      & color        = COLOR_PLANE,
                      float               transparency = 0.2f       ) const override;

    Camera& operator=(const Camera& p);



};
#endif // CAMERA_H
